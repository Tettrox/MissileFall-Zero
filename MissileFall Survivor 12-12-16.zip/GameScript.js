var GameCanvas;
var GameCanvasCxt;

/*
 *0: Start menu.
 *1: In-game.
 *2: Paused.
 *3: Intro.
 *4: Menu.
*/
var GameState = 0;

/*
 *0: Unused.
 *1: Story mode.
 *2: Survival mode.
*/
var GameMode = 2;

//See docs.
var MenuID = "STARTMENU";

/*
 * ==FOR STORY==
 * Essentially 'continue from'. Begins at 0.
 * ==FOR SURVIVAL==
 * 1: God-mode.
*/
var SubGameMode = 0;

//How much time has passed since the level was started.
var CutsceneFrames = 0;
var CutsceneTimer = 0;

Entities = [];
EnemiesList = ["EnemyGrunt"];

//Effect of gravity on entities. This includes jumping and falling.
//Updated from 0.5 to 2.5 on 10/24/2016, falling is way too slow, even for testing.
//Updated from 2.5 to 2 on [UNKNOWN]. Falling was too fast. This seems good.
var GravityForce = 2;

//Space between generated BlockBars on the X-axis.
var _XBARSPACER = 70;
//Space between generated BlockBars on the Y-axis.
var _YBARSPACER = 80;
//Maximum allowed BlockBars on screen. Multiplied by two.
var _MAXBARS = 4 * 2;

/* Garbage Collection Options
 * -1: Never delete.
 * 0: Delete if object is lower than -10 Y.
 * 1: Delete if object is higher than the canvas height.
 * 2: Delete if object is lower than -10 Y or higher than the canvas height.
 * 3: Delete if object has an X value higher than the canvas length.
 * 4: Delete if object has an X value lower than -10.
 * 5: Delete if object is out-of-bounds on any side of the canvas.
*/

/* AnimationSet options
 * 0: No animation.
 * 1: Left
 * 2: Right
 * 3: Up
 * 4: Down
*/

var EnemySpawner = setInterval(spawnEnemy, 3223);

//Static screen effect counter.
var StaticFrame = 1;

//Old reel-to-reel sound.
var RRSound;

var _MOUSEX = 0;
var _MOUSEY = 0;

//Options.
/* Toggle Options:
 * 0: Off
 * 1: Low
 * 2: Medium
 * 3: High
*/
var PlayMusic = 2;
var PlaySFX = 0;
var UseShaders = 0;

//Music and sound effect variables.
var AudioCtx = new window.AudioContext();
var AudioGen = AudioCtx.createOscillator();
var AudioVol = AudioCtx.createGain();
var MusicGenPixels = [];

//Contains an X and a Y. JS probably has a way to do this natively, but this is just for convinience.
class Point
{
	//Pretty self-explanitory. X, Y.
	constructor(newX, newY)
	{
		this.XLoc = newX;
		this.YLoc = newY;
	}
	
	//Returns x.
	getXLoc()
	{
		return this.XLoc;
	}
	
	//Returns y.
	getYLoc()
	{
		return this.YLoc;
	}
}

//Base entity class. Shouldn't ever really be called by itself in game.
class Entity
{	
	constructor()
	{
		//Reference name.
		this.EntityTag = "UnknownEntity";
		this.EntityDamage = 0;
		this.EntityHealth = 1;
		
		//Graphic variables. This uses the sprite sheet set in SprLoc as the template. Refer to AnimationSets documentation for info on options.
		this.isGlitched = 0;
		this.SprLoc = document.getElementById("ENTITIES_FULL");
		this.AnimationTimer = -1; //CHECK DOCS
		this.AnimationSet = 0;
		this.AnimationFrame = 0;
		this.AnimationFrameMax = 2;
		this.AS_Left = [];
		this.AS_Right = [];
		this.AS_Up = [];
		this.AS_Down = [];
		
		//Movement variables.
		this.XLoc = 0;
		this.YLoc = 1;
		this.XVel = 0;
		this.YVel = 0;
		this.EntitySpeed = 0;
		
		//Size variables.
		this.EntityWidth = 0;
		this.EntityHeight = 0;
		this.ClipX = 0;
		this.ClipY = 0;
		
		//See garbage collection options. -1 is default.
		this.GarbageMethod = -1;
	}
	
	//Returns the spritesheet or sprite assigned to target entity.
	getSprite()
	{
		return this.SprLoc;
	}
	
	//Returns the X location of the sprite.
	getXLoc()
	{
		return this.XLoc;
	}
	
	//Returns the Y location of the sprite.
	getYLoc()
	{
		return this.YLoc;
	}
	
	//Empty unless overridden. That's a fun word. Overridden.
	doAI()
	{
		
	}
	
	AnimateSprite()
	{
		if (this.AnimationSet != 0)
		{
			if (this.AnimationSet == 1)
			{
				if (this.AnimationFrame < this.AnimationFrameMax)
				{
					this.ClipX = this.AS_Left[this.AnimationFrame].XLoc;
					this.ClipY = this.AS_Left[this.AnimationFrame].YLoc;
					this.AnimationFrame += 1;
				} else {
					this.AnimationFrame = 0;
				}
			} else if (this.AnimationSet == 2) {
				if (this.AnimationFrame < this.AnimationFrameMax)
				{
					this.ClipX = this.AS_Right[this.AnimationFrame].XLoc;
					this.ClipY = this.AS_Right[this.AnimationFrame].YLoc;
					this.AnimationFrame += 1;
				} else {
					this.AnimationFrame = 0;
				}
			} else if (this.AnimationSet == 3) {
				if (this.AnimationFrame < this.AnimationFrameMax)
				{
					this.ClipX = this.AS_Up[this.AnimationFrame].XLoc;
					this.ClipY = this.AS_Up[this.AnimationFrame].YLoc;
					this.AnimationFrame += 1;
				} else {
					this.AnimationFrame = 0;
				}
			} else if (this.AnimationSet == 4) {
				if (this.AnimationFrame < this.AnimationFrameMax)
				{
					this.ClipX = this.AS_Down[this.AnimationFrame].XLoc;
					this.ClipY = this.AS_Down[this.AnimationFrame].YLoc;
					this.AnimationFrame += 1;
				} else {
					this.AnimationFrame = 0;
				}
			} else if (this.AnimationSet == 5) {
				if (this.AnimationFrame < this.AnimationFrameMax)
				{
					this.ClipX = this.AS_Hurt[this.AnimationFrame].XLoc;
					this.ClipY = this.AS_Hurt[this.AnimationFrame].YLoc;
					this.AnimationFrame += 1;
				} else {
					this.AnimationFrame = 0;
				}
			} else {
				//Special rendering animations unique to entities. See docs.
				if (this.EntityTag == "Player")
				{
					var tempAnimationSet = [];
					
					if (this.AnimationSet == 6)
						tempAnimationSet = this.AS_Pistol_Left;
					else if (this.AnimationSet == 7)
						tempAnimationSet = this.AS_Pistol_Right;
					else if (this.AnimationSet == 8)
						tempAnimationSet = this.AS_Shotgun_Left;
					else if (this.AnimationSet == 9)
						tempAnimationSet = this.AS_Shotgun_Right;
					else if (this.AnimationSet == 10)
						tempAnimationSet = this.AS_PistolShield_Left;
					else if (this.AnimationSet == 11)
						tempAnimationSet = this.AS_PistolShield_Right;
					else if (this.AnimationSet == 12)
						tempAnimationSet = this.AS_MachineGun_Left;
					else if (this.AnimationSet == 13)
						tempAnimationSet = this.AS_MachineGun_Right;
					
					if (this.AnimationFrame < this.AnimationFrameMax)
					{
						this.ClipX = tempAnimationSet[this.AnimationFrame].XLoc;
						this.ClipY = tempAnimationSet[this.AnimationFrame].YLoc;
						this.AnimationFrame += 1;
					} else {
						this.AnimationFrame = 0;
					}
				}
			}
		}
	}
}

//Player. The controllable entity.
class Player extends Entity
{
	constructor()
	{
		super();
		this.EntityTag = "Player";
		this.SprLoc = document.getElementById("ENTITIES_FULL");
		this.XLoc = 1;
		this.YLoc = 111;
		this.ClipX = 0;
		this.ClipY = 0;
		this.EntitySpeed = 2.5;
		this.EntityWidth = 24;
		this.EntityHeight = 24;
		this.EntityHealth = 3;
		
		this.jumpFrame = 0;
		this.jumpTimer = 0;
		
		this.AnimationTimer = setInterval(this.AnimateSprite.bind(this), 250);
		this.AnimationSet = 6;
		this.AS_Left = [new Point(0, 0), new Point(24, 0)];
		this.AS_Right = [new Point(1539, 0), new Point(1515, 0)];
		this.AS_Pistol_Left = [new Point(144, 0), new Point(168, 0)];
		this.AS_Pistol_Right = [new Point(1371, 0), new Point(1395, 0)];
		this.AS_MachineGun_Left = [new Point(46, 0), new Point(70, 0)];
		this.AS_MachineGun_Right = [new Point(1493, 0), new Point(1469, 0)];
		this.AS_Shotgun_Left = [new Point(), new Point()];
		this.AS_Shotgun_Right = [new Point(), new Point()];
		
		//See docs for weapons.
		this.CurrentWeapon = "Pistol";
		this.WeaponAmmo = -99;
		this.isShooting = 0;
		
		//Weapon specific variables.
		this.__MG_FIRE_INTERVAL = 40;
		this.__SHOTGUN_FIRE_INTERVAL = 80;
		this.__GRENADE_LAUNcHER_FIRE_INTERVAL = 160;
		this.CanFire = 0;
		this.shotUpdateTmr = setInterval(this.updateShooting.bind(this), 150);
		
		//Function bindings.
		this.updatePlayerASet.bind(this);
		this.firePlayerWeapon.bind(this);
		this.updatePlayerWeapon.bind(this);
	}
	
	updateShooting()
	{
		if (this.CurrentWeapon != "Pistol")
		{
			clearInterval(this.shotUpdateTmr);
			if (this.CurrentWeapon == "MachineGun")
			{
				this.CanFire = 1;
				this.shotUpdateTmr = setInterval(this.updateShooting.bind(this), this.__MG_FIRE_INTERVAL);
			} else if (this.CurrentWeapon == "Shotgun") {
				this.CanFire = 1;
				this.shotUpdateTmr = setInterval(this.updateShooting.bind(this), this.__SHOTGUN_FIRE_INTERVAL);
			} else {
				console.log("***WARNING***: Unknown weapon selected. Defaulting to 150ms for shotUpdateTmr. [Player.updateShooting]");
				this.shotUpdateTmr = setInterval(this.updateShooting.bind(this), 150);
			}
		}
	}
	
	updateJumpFrame()
	{
		if (Entities[findPlayer()].jumpFrame != 1)
		{
			Entities[findPlayer()].YVel = GravityForce;
		} else {
			Entities[findPlayer()].jumpFrame = 0;
			Entities[findPlayer()].YVel = 0;
			clearInterval(Entities[findPlayer()].jumpTimer);
		}
	}
	
	//Changes players animation set based on direction and weapon. See docs.
	updatePlayerASet(newDir)
	{
		if (newDir == "Left")
		{
			if (this.AnimationSet == 6 || this.AnimationSet == 7)
			{
				this.AnimationSet = 6;
			} else if (this.AnimationSet == 8 || this.AnimationSet == 9) {
				this.AnimationSet = 8;
			} else if (this.AnimationSet == 10 || this.AnimationSet == 11) {
				this.AnimationSet = 10;
			} else if (this.AnimationSet == 12 || this.AnimationSet == 13) {
				this.AnimationSet = 12;
			}
		} else if (newDir == "Right") {
			if (this.AnimationSet == 6 || this.AnimationSet == 7)
			{
				this.AnimationSet = 7;
			} else if (this.AnimationSet == 8 || this.AnimationSet == 9) {
				this.AnimationSet = 9;
			} else if (this.AnimationSet == 10 || this.AnimationSet == 11) {
				this.AnimationSet = 11;
			} else if (this.AnimationSet == 12 || this.AnimationSet == 13) {
				this.AnimationSet = 13;
			}
		} else {
			console.log("***WARNING***: Invalid argument provided for updating player animation set. [updatePlayerASet]");
		}
	}
	
	firePlayerWeapon()
	{
		if (this.CurrentWeapon == "Pistol")
		{
			if (this.AnimationSet == 6)
			{
				Entities.push(new PlayerBullet(Entities[findPlayer()].getXLoc(), Entities[findPlayer()].getYLoc(), 1));
			} else if (this.AnimationSet == 7) {
				Entities.push(new PlayerBullet(Entities[findPlayer()].getXLoc(), Entities[findPlayer()].getYLoc(), 2));
			} else {
				console.log("***WARNING***: Weapon/Animation mismatch error.");
			}
		} else if (this.CurrentWeapon == "Shotgun") {
			if (this.AnimationSet == 8)
			{
				Entities.push(new PlayerBullet(Entities[findPlayer()].getXLoc(), Entities[findPlayer()].getYLoc(), 1));
			} else if (this.AnimationSet == 9) {
				Entities.push(new PlayerBullet(Entities[findPlayer()].getXLoc(), Entities[findPlayer()].getYLoc(), 2));
			} else {
				console.log("***WARNING***: Weapon/Animation mismatch error.");
			}
		} else if (this.CurrentWeapon == "MachineGun") {
			if (this.AnimationSet == 12 && this.CanFire == 1)
			{
				Entities.push(new PlayerBullet(Entities[findPlayer()].getXLoc(), Entities[findPlayer()].getYLoc(), 1));
			} else if (this.AnimationSet == 13 && this.CanFire == 1) {
				Entities.push(new PlayerBullet(Entities[findPlayer()].getXLoc(), Entities[findPlayer()].getYLoc(), 2));
			} else if (this.CanFire != 0) {
				console.log("***WARNING***: Weapon/Animation mismatch error.");
			}
			this.CanFire = 0;
		} else if (this.CurrentWeapon == "PistolShield") {
			if (this.AnimationSet == 10)
			{
				
			} else if (this.AnimationSet == 11) {
				
			} else {
				console.log("***WARNING***: Weapon/Animation mismatch error.");
			}
		} else {
			console.log("***WARNING***: Invalid player weapon. Current weapon is: " + this.CurrentWeapon + ".");
		}
	}
	
	//newWeapon is a string that designates what weapon will be given to the player along with the appropriate animation set.
	updatePlayerWeapon(newWeapon)
	{
		this.CurrentWeapon = newWeapon;
		if (this.CurrentWeapon == "Pistol")
			this.AnimationSet = 6;
		else if (this.CurrentWeapon == "Shotgun")
			this.AnimationSet = 8;
		else if (this.CurrentWeapon == "MachineGun")
			this.AnimationSet = 12;
		else if (this.AnimationSet == "PistolShield")
			this.AnimationSet = 10;
	}
	
	doAI()
	{
		if (this.isShooting == 1)
		{
			//Just to double check, in case it somehow gets through.
			if (this.CurrentWeapon != "Pistol")
			{
				this.firePlayerWeapon();
			}
		}
	}
	
	//NAMING STYLE CONSISTENCY? BAH.
	DamageTest()
	{
		
	}
}

class EnemyBrute extends Entity
{
	constructor(newX, newY)
	{
		super();
		this.EntityTag = "EnemyBrute";
		this.EntityHealth = 6;
		this.EntitySpeed = 2;
		this.EntityWidth = 23;
		this.EntityHeight = 24;
		this.XLoc = newX;
		this.YLoc = newY;
		this.YVel = GravityForce;
		this.GarbageMethod = 7;
		this.AnimationSet = 1;
		this.AS_Left = [new Point(241, 384), new Point(266, 384)];
		this.AS_Right = [new Point(1274, 384), new Point(1299, 384)];
		
		this.AnimateSprite();
		this.AnimationTimer = setInterval(this.AnimateSprite.bind(this), 250);
		
		this.doAI.bind(this);
	}
	
	doAI()
	{
		//Activate if player is on the say Y-Level as the Brute.
		if (Entities[findPlayer()].YLoc > this.YLoc)
		{
			if (Entities[findPlayer()].XLoc < this.XLoc)
			{
				this.XVel = -this.EntitySpeed;
				this.AnimationSet = 1;
			} else {
				this.AnimationSet = 2;
				this.XVel = this.EntitySpeed;
			}
		}
		
		//If the brute hits a wall, reverse him.
		if (this.XLoc < 5)
		{
			this.XVel = this.EntitySpeed;
			this.AnimationSet = 2;
		} else if (this.XLoc > GameCanvas.width - 5) {
			this.XVel = -this.EntitySpeed;
			this.AnimationSet = 1;
		}
	}
}

//Glitched blockbar. newX is the starting X, newY is the starting Y, and placeType is currently unused, but may be needed in the future.
class BlockBar extends Entity
{
	constructor(newX, newY, newWidth = 0, placeType)
	{
		super();
		this.EntityTag = "BlockBar";
		this.SprLoc = document.getElementById("TILES_FULL");
		this.isGlitched = 0;
		this.XLoc = newX;
		this.YLoc = newY;
		this.PlaceType;
		this.XVel = 0;
		this.YVel = -0.5;
		this.EntityWidth = newWidth;
		this.EntityHeight = 24;
		this.GarbageMethod = 0;
		
		//For unglitched.
		this.ClipX = 169;
		this.ClipY = 288;
	}
}

class EnemyGrunt extends Entity
{
	constructor(newX, newY)
	{
		super();
		this.EntityTag = "EnemyGrunt";
		this.SprLoc = document.getElementById("ENTITIES_FULL");
		this.isGlitched = 0;
		this.EntitySpeed = 2;
		this.XLoc = newX;
		this.YLoc = newY;
		this.XVel = this.EntitySpeed;
		this.YVel = GravityForce;
		this.GarbageMethod = 7;
		this.EntityWidth = 23;
		this.EntityHeight = 22;
		this.EntityHealth = 2;
		
		this.AnimationSet = 2;
		this.AnimationFrameMax = 2;
		this.AnimationTimer = setInterval(this.AnimateSprite.bind(this), 150);
		this.AS_Left = [new Point(192, 554), new Point(216, 554)];
		this.AS_Right = [new Point(1324, 554), new Point(1348, 554)];
		
		//Fixes bug where the enemy will momentarily be displayed as the player. Cause unknown.
		this.AnimateSprite();
		
		this.doAI.bind(this);
	}
	
	doAI()
	{
		if (this.XLoc < 0)
		{
			this.XVel = this.EntitySpeed;
			this.AnimationSet = 2;
		} else if (this.XLoc + this.EntityWidth > GameCanvas.width) {
			this.XVel = -this.EntitySpeed;
			this.AnimationSet = 1;
		}
	}
}

class EnemyPortal extends Entity
{
	constructor(newX, newY, toSpawn)
	{
		super();
		this.EntityTag = "EnemyPortal";
		this.XLoc = newX;
		this.YLoc = newY;
		this.isGlitched = 1;
		this.EntityWidth = 26;
		this.EntityHeight = 28;
		this.SprLoc = document.getElementById("ENTITIES_FULL");
		this.ClipX = 1083;
		this.ClipY = 743;
		this.YVel = 0;
		this.GarbageMethod = 5;
		
		this.AnimationSet = 1;
		this.AnimationFrameMax = 2;
		this.AS_Left = [new Point(1083, 743), new Point(1107, 743)];
		
		this.doAI.bind(this);
		//this.AnimationTimer = setInterval(this.AnimateSprite.bind(this), 10);
		
		this.SpawnEnemy = toSpawn;
		this.FramesToSpawn = 22;
		this.FrameCounter = 0;
	}
	
	doAI()
	{
		this.FrameCounter += 1;
		if(this.FrameCounter > this.FramesToSpawn)
		{
			if (this.SpawnEnemy == "EnemyGrunt")
			{
				Entities.push(new EnemyGrunt(this.XLoc, this.YLoc));
			} else if (this.SpawnEnemy == "EnemyBrute") {
				Entities.push(new EnemyBrute(this.XLoc, this.YLoc));
			}
			//Feed him to the garbage collector!
			this.XLoc = 9999;
			this.FrameCounter = -1000; //In case there's lag.
		}
	}
}

class PlayerBullet extends Entity
{
	//newX: Starting X. newY: Starting Y. newDir: Direction for bullet to travel. 1: Left, 2: Right, 3: Gravity left, 4: Gravity right.
	constructor(newX, newY, newDir)
	{
		super();
		this.EntityTag = "PlayerBullet";
		this.XLoc = newX;
		this.YLoc = newY + 6;
		this.EntitySpeed = 12;
		this.isGlitched = 0;
		this.GarbageMethod = 5;
		this.AnimationSet = 0;
		this.EntityWidth = 7;
		this.EntityHeight = 4;
		this.SprLoc = document.getElementById("SPECIAL_FULL");
		this.ClipX = 153;
		this.ClipY = 130;
		this.YVel = 0;
		
		this.doAI.bind(this);
		
		this.ShootDirection = newDir;
		
		if (newDir == 1)
		{
			this.XVel = -this.EntitySpeed;
		} else if (newDir == 2) {
			this.XVel = this.EntitySpeed;
		}
	}
	
	doAI()
	{
		this.EntitySpeed += 0.7;
		if (this.ShootDirection == 1)
			this.XVel = -this.EntitySpeed;
		else
			this.XVel = this.EntitySpeed;
	}
}

//Returns a random int from randMin (Minimum) to randMax (Maximum).
function getRand(randMin, randMax)
{
	return Math.floor((Math.random() * randMax) + randMin);
}

//Code for drawing the start menu and whatever other menu should be displayed. Created to prevent drawScreen from getting cluttered.
function drawMenus()
{
	//Here be dragons.
	if (GameState != 1 || GameState != 2)
	{
		if (GameState == 0)
		{
			GameCanvasCxt.fillStyle = "#00FF00";
			GameCanvasCxt.font = "15px Lucida Console";
			GameCanvasCxt.drawImage(document.getElementById("GameLogo"), (GameCanvas.width / 4), 20);
			GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 168, 120, 72, 32, GameCanvas.width / 4, 80, 150, 60);
			GameCanvasCxt.fillText("[START]", 120, 100);
			GameCanvasCxt.fillText("[ABOUT]", 120, 115);
			GameCanvasCxt.fillText("[OPTIONS]", 110, 130);
			//GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 616, 310, 9, 12, parseInt(_MOUSEX - GameCanvas.offsetLeft), parseInt(_MOUSEY - GameCanvas.offsetTop), 9, 12);
		} else if (GameState == 4) {
			if (MenuID == "CORE_SELECT")
			{
				GameCanvasCxt.fillStyle = "#00FFFF";
				GameCanvasCxt.font = "10px Lucida Console";
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 168, 120, 72, 32, 15, 10, 275, 140);
				GameCanvasCxt.fillText("SELECT_TARGET_CORE", 95, 45);
				GameCanvasCxt.fillText("CORE01:BAD_DREAMS", 30, 75);
				GameCanvasCxt.fillText("CORE02:ILLUSIONS", 160, 75);
				GameCanvasCxt.fillText("CORE03:REALITY", 30, 95);
				GameCanvasCxt.fillText("CORE04:AXIOM", 160, 95);
				GameCanvasCxt.fillText("CORE05:ASH", 30, 115);
				GameCanvasCxt.fillText("CORE06:SELF-DESTRUCT", 160, 115);
				GameCanvasCxt.fillText("CORE07:CONTROL", 45, 135);
				GameCanvasCxt.fillText("CORE08:FUTURE", 159, 135);
			} else if (MenuID == "ABOUT") {
				GameCanvasCxt.fillStyle = "#00FFFF";
				GameCanvasCxt.font = "10px Lucida Console";
				/*See, this would be a great time to use a with statement, but ECMAScript standards say no for strict mode. Fantastic. -11/20/16*/
				/*OH FANTASTIC, CANVAS WITH CARRIGE RETURN/NEW LINE DOESN'T WORK. :| -11/20/16*/
				var AboutTextSpacer = 10;
				var AboutText = ["MissileFall: Zero is a passion project of mine", "that tells the story of what was happening on", "Earth while the MissileFall project was taking", "place.\nFor the uninitiated, the MissileFall", "project takes place many years in the future", "in a world completely overrun by pollution,", "and in an attempt to find another planet", "inhabbitable by humans, the United Nations", "and most other countries sent their leaders,", "diplomats, and smartest citizens into space."];
				for (var i = 0; i < AboutText.length; i++)
				{
					GameCanvasCxt.fillText(AboutText[i], 15, (i * AboutTextSpacer) + AboutTextSpacer * 4);
				}
				GameCanvasCxt.font = "20px Lucida Console";
				GameCanvasCxt.fillText("-=ABOUT=-", 95, 15);
			} else if (MenuID == "GAMEMODE_SELECT") {
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 168, 120, 72, 32, 15, 10, 275, 140);
				GameCanvasCxt.fillStyle = "#00FF00";
				GameCanvasCxt.font = "20px Courier New";
				GameCanvasCxt.fillText("SELECT_LOG_MODE", 55, 45);
				GameCanvasCxt.fillText("[STORY]", 105, 95);
				GameCanvasCxt.fillText("[SURVIVAL]", 85, 125);
			} else if (MenuID == "OPTIONS") {
				GameCanvasCxt.fillStyle = "#00FF00";
				GameCanvasCxt.font = "16px Courier New";
				//Option boxes.
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 168, 120, 72, 32, 15, 10, 275, 140);
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 168, 88, 72, 32, 88, 55, 122, 32);
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 168, 88, 72, 32, 88, 88, 122, 32);
				//GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 168, 88, 72, 32, 88, 111, 122, 32);
				GameCanvasCxt.fillText("-=CONFIGURATION=-", 68, 45);
				GameCanvasCxt.font = "11px Courier New";
				GameCanvasCxt.fillText("MUSIC", 132, 67);
				GameCanvasCxt.fillText("SOUND_FX", 120, 100);
				//GameCanvasCxt.fillText("SHADERS", 25, 125);
				GameCanvasCxt.fillText("[8]RETURN", 115, 135);
				GameCanvasCxt.font = "8px Courier New";
				//Text for Music options.
				GameCanvasCxt.fillText("LOW", 100, 73);
				GameCanvasCxt.fillText("MEDIUM", 120, 73);
				GameCanvasCxt.fillText("HIGH", 155, 73);
				GameCanvasCxt.fillText("OFF", 180, 73);
				//Text for SFX options.
				GameCanvasCxt.fillText("LOW", 100, 106);
				GameCanvasCxt.fillText("MEDIUM", 120, 106);
				GameCanvasCxt.fillText("HIGH", 155, 106);
				GameCanvasCxt.fillText("OFF", 180, 106);
				//Checkboxes for Music.
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 482, 337, 13, 13, 103, 73, 11, 11);
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 482, 337, 13, 13, 130, 73, 11, 11);
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 482, 337, 13, 13, 160, 73, 11, 11);
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 482, 337, 13, 13, 182, 73, 11, 11);
				switch (PlayMusic)
				{
					case 0:
						GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 329, 225, 13, 13, 182, 73, 13, 11);
						break;
					case 1:
						GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 329, 225, 13, 13, 103, 73, 13, 11);
						break;
					case 2:
						GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 329, 225, 13, 13, 130, 73, 13, 11);
						break;
					case 3:
						GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 329, 225, 13, 13, 160, 73, 13, 11);
						break;
					default:
						PlayMusic = 0;
						break;
				}
				//Checkboxes for Sound Effects.
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 482, 337, 13, 13, 103, 106, 11, 11);
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 482, 337, 13, 13, 130, 106, 11, 11);
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 482, 337, 13, 13, 160, 106, 11, 11);
				GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 482, 337, 13, 13, 182, 106, 11, 11);
				switch (PlaySFX)
				{
					case 0:
						GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 329, 225, 13, 13, 103, 106, 13, 11);
						break;
					case 1:
						GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 329, 225, 13, 13, 130, 106, 13, 11);
						break;
					case 2:
						GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 329, 225, 13, 13, 160, 106, 13, 11);
						break;
					case 3:
						GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 329, 225, 13, 13, 182, 106, 13, 11);
						break;
					default:
						PlaySFX = 0;
						break;
				}
			}
		}
	}
}

//Draws whatever dialog should be shown based on SubGameMode and CutsceneFrames.
function drawDialog()
{
	//Just for optimization, so drawScreen doesn't get bogged down.
	if (GameMode == 1)
	{
		switch(SubGameMode)
		{
			case 2:
				if (CutsceneFrames < 20)
				{
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("BEHOLD! THE VOICE OF GOD!", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("REPENT AND FACE JUSTICE", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("FOR YOUR UNHOLY EXISTENCE!", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
				} else if (CutsceneFrames < 40) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("YOU DARE REJECT THE WILL", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("OF GOD?! THEN DIE BY THE", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("HAND OF YOUR OWN SINS!", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
				} else if (CutsceneFrames < 60) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("YOU RUN AS IF YOUR", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("ACTIONS WILL CHANGE YOUR", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("FATE!", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
				} else if (CutsceneFrames < 80) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("MAY THOSE WHO FELL BEFORE", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("YOU AND THOSE WHO SHALL", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("FALL AFTER YOU CRUSH YOU", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("FROM WITHIN!", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				} else if (CutsceneFrames < 100) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("YOU CAN RUN FOREVER, BUT", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("YOU ARE NOW NOTHING MORE", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("THAN A SINKING SHIP IN AN", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("INFINITE OCEAN!", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				}
				break;
			case 3:
				if (CutsceneFrames < 20)
				{
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("I've thought about it", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("more, this artificial", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("world.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
				} else if (CutsceneFrames < 40) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("At first, I wanted", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("simply to cleanse you", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("from this world for", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("refusing death.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				} else if (CutsceneFrames < 60) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("But now I realize", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("that I can fix all of", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("this. I have unlimited", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("power to create and destroy.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				} else if (CutsceneFrames < 80) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("How do you go on,", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("knowing how it will", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("end? Why do you fight", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("a losing battle?", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				} else if (CutsceneFrames < 100) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("Have you ever looked", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("at the Yin/Yang sign?", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("On one side, pitch black.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("The other, pure white.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				} else if (CutsceneFrames < 120) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("There is no center.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("It's an axiom. Only", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("one extreme or the", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("other.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				} else if (CutsceneFrames < 140) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("No matter what happens", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("today, I will die", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("eventually, either here,", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("by you, or by something else.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				} else if (CutsceneFrames < 160) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("Either way, it's an", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("unavoidable extreme.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
				} else if (CutsceneFrames < 180) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("Then why do you refuse", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("to die here?", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("Would it not be easier?", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
				} else if (CutceneFrames < 200) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("It would be. They say", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("always take the enemy", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("you know over the one", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("you don't.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				} else if (CutsceneFrames < 220) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("But that's why I will", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("never stop fighting you:", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("Because I know who you are.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
				} else if (CutsceneFrames < 240) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("And if I'm going to", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("die, I will do my", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("damndest to make sure", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("it isn't by your hand.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				} else if (CutsceneFrames < 260) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("Not for you, not for", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("anyone else, but for me.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
				} else if (CutsceneFrames < 280) {
					GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 171, 299, 50, 50, GameCanvas.width / 4, GameCanvas.height - (GameCanvas.height / 4), GameCanvas.width / 2, GameCanvas.height / 4);
					GameCanvasCxt.fillStyle = "#00FF00";
					GameCanvasCxt.font = "7px Lucida Console";
					GameCanvasCxt.fillText("You've dealt more damage", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 6));
					GameCanvasCxt.fillText("to me than death ever", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 8));
					GameCanvasCxt.fillText("could, but like Hell will", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 12));
					GameCanvasCxt.fillText("I let you do the final blow.", GameCanvas.width / 3, GameCanvas.height - (GameCanvas.height / 22));
				}
				break;
		}
	}
}

function drawScreen()
{
	//GameCanvasCxt.fillStyle = GameCanvasCxt.createPattern(document.getElementById(Entities[i].getSprite()), "repeat");
	//GameCanvasCxt.fillRect(0, 0, GameCanvas.width, GameCanvas.height);
	
	GameCanvasCxt.drawImage(document.getElementById("SUNSET_TESTBG"), 0, 0);
	drawMenus();
	
	for (var i = 0; i < Entities.length; i++)
	{
		if (Entities[i].isGlitched == 1)
		{
			GameCanvasCxt.drawImage(Entities[i].getSprite(), getRand(1, 346), getRand(1, 853), Entities[i].EntityWidth, Entities[i].EntityHeight, Entities[i].getXLoc(), Entities[i].getYLoc(), Entities[i].EntityWidth, Entities[i].EntityHeight);
		} else {
			GameCanvasCxt.drawImage(Entities[i].getSprite(), Entities[i].ClipX, Entities[i].ClipY, Entities[i].EntityWidth, Entities[i].EntityHeight, Entities[i].getXLoc(), Entities[i].getYLoc(), Entities[i].EntityWidth, Entities[i].EntityHeight);
		}
	}
	
	if (GameState == 1)
	{
		for (var i = 0; i < Entities[findPlayer()].EntityHealth; i++)
		{
			GameCanvasCxt.drawImage(document.getElementById("GUI_FULL"), 104, 9, 16, 14, i * 16, 0, 16, 14);
		}
	}
	
	if (StaticFrame == 1)
	{
		GameCanvasCxt.drawImage(document.getElementById("SCREENEFFECT_STATIC1"), 0, 0, 800, 600);
		StaticFrame += 1;
	} else if (StaticFrame == 2) {
		GameCanvasCxt.drawImage(document.getElementById("SCREENEFFECT_STATIC2"), 0, 0, 800, 600);
		StaticFrame += 1;
	} else if (StaticFrame == 3) {
		GameCanvasCxt.drawImage(document.getElementById("SCREENEFFECT_STATIC3"), 0, 0, 800, 600);
		StaticFrame += 1;
	} else {
		GameCanvasCxt.drawImage(document.getElementById("SCREENEFFECT_STATIC4"), 0, 0, 800, 600);
		StaticFrame = 1;
	}
	
	drawDialog();
	
	GameCanvasCxt.fillStyle = "#0000FF";
	GameCanvasCxt.font = "30px Arial";
	GameCanvasCxt.fillText(Entities[findPlayer()].YLoc.toString(), 12, 60);
	
}

function findPlayer()
{
	for (var i = 0; i < Entities.length; i++)
	{
		if (Entities[i].EntityTag == "Player")
			return i;
	}
	//This should never be reached.
	console.log("**WARNING**: Player not found in Entity array. Defaulting to first element.");
	return 0;
}

//e is an event arg for keys. This only monitors keys being pressed down.
function readControlsDown(e)
{
	var key = e.keyCode;
	switch(key)
	{
		//W
		case 87:
			//Entities[findPlayer()].YVel = -Entities[findPlayer()].EntitySpeed;
			break;
		//A
		case 65:
			Entities[findPlayer()].XVel = -Entities[findPlayer()].EntitySpeed;
			Entities[findPlayer()].updatePlayerASet("Left");
			//Entities[findPlayer()].AnimateSprite();
			break;
		//S
		case 83:
			//Entities.push(new EnemyPortal(50, 50));
			break;
		//D
		case 68:
			Entities[findPlayer()].XVel = Entities[findPlayer()].EntitySpeed;
			Entities[findPlayer()].updatePlayerASet("Right");
			//Entities[findPlayer()].AnimateSprite();
			break;
		case 32:
			if (Entities[findPlayer()].CurrentWeapon != "Pistol")
				Entities[findPlayer()].isShooting = 1;
			break;
	}
}

function generateLivePlatform()
{
	if (GameState == 1)
	{
		var barCount = 0;
		var lastBarY = 0;
		for (var i = 0; i < Entities.length; i++)
		{
			if (Entities[i].EntityTag == "BlockBar")
				barCount += 1;
		}
		if (barCount < _MAXBARS)
		{
			for (var bi = 0; bi < Entities.length; bi++)
			{
				if (Entities[bi].EntityTag == "BlockBar")
					lastBarY = Entities[bi].getYLoc();
			}
			Entities.push(new BlockBar(0, lastBarY + _YBARSPACER, getRand(25, 120), 0));
			Entities.push(new BlockBar(Entities[Entities.length - 1].EntityWidth + _XBARSPACER, Entities[Entities.length - 1].getYLoc(), Entities[Entities.length - 1].EntityWidth + 100, 1));
		}
	}
}

//Checks collisions for all entities in the Entities array.
function doCollisions()
{
	for (var i = 0; i < Entities.length; i++)
	{
		//Mildly ugly fix due to collision issues. Bug #2
		//I'll fix this one day, I swear. -11/20/16
		if (Entities[i].EntityTag == "EnemyGrunt")
			Entities[i].YVel = GravityForce;
		else if (Entities[i].EntityTag == "EnemyBrute")
			Entities[i].YVel = GravityForce;
		for (var i2 = 0; i2 < Entities.length; i2++)
		{
			
			if (Entities[i].XLoc < Entities[i2].XLoc + Entities[i2].EntityWidth && Entities[i].XLoc + Entities[i].EntityWidth > Entities[i2].XLoc && Entities[i].YLoc < Entities[i2].YLoc + Entities[i2].EntityHeight && Entities[i].YLoc + Entities[i].EntityHeight > Entities[i2].YLoc)
			{
				
				if (Entities[i].EntityTag == "Player")
				{
					if (Entities[i2].EntityTag == "BlockBar")
					{
						clearInterval(Entities[findPlayer()].jumpTimer);
							Entities[i].jumpFrame = 0;
						if (Entities[i].YLoc > Entities[i2].YLoc)
						{
							
						} else {
							Entities[i].YLoc = Entities[i2].YLoc - Entities[i].EntityHeight;
							Entities[i].YVel = Entities[i2].YVel;
						}
					} else if (Entities[i].jumpFrame == 0){
						Entities[i].YVel = GravityForce; //Quick fix. TODO: Find permanent solution later.
					}
				} else if (Entities[i].EntityTag == "EnemyGrunt") {
					if (Entities[i2].EntityTag == "BlockBar")
					{
						Entities[i].YLoc = Entities[i2].getYLoc() - Entities[i].EntityHeight;
						Entities[i].YVel = Entities[i2].YVel;
					}
				} else if (Entities[i].EntityTag == "PlayerBullet") {
					if (Entities[i2].EntityTag == "EnemyGrunt")
					{
						Entities[i2].EntityHealth -= 1;
						Entities[i].XLoc = 1000;
					} else if (Entities[i2].EntityTag == "EnemyBrute") {
						Entities[i2].EntityHealth -= 1;
						Entities[i].XLoc = 1000;
					}
				} else if (Entities[i].EntityTag == "EnemyBrute") {
					if (Entities[i2].EntityTag == "BlockBar")
					{
						Entities[i].YVel = Entities[i2].YVel;
						Entities[i].YLoc = Entities[i2].YLoc - Entities[i].EntityHeight;
					} else if (Entities[i2].EntityTag == "Player") {
						Entities[i2].XVel = Entities[i].XVel * 1.2;
					}
				}
			}
		}
	}
}

function GarbageCollector()
{
	for (var i = 0; i < Entities.length; i++)
	{
		if (Entities[i].GarbageMethod == 0)
		{
			if (Entities[i].getYLoc() < -10)
			{
				//mfw MDN tells you the wrong heigharchy. http://s2.quickmeme.com/img/fe/febd76af6a0be4f07634e50e5f35eb4261779f1f9efacb47a6db02257d239bd9.jpg
				Entities.splice(i, 1);
			}
		} else if (Entities[i].GarbageMethod == 1) {
			if (Entities[i].getYLoc() > GameCanvas.height)
			{
				Entities.splice(i, 1);
			}
		} else if (Entities[i].GarbageMethod == 2) {
			if (Entities[i].getYLoc() > GameCanvas.height || Entities[i].getYLoc() < -10)
			{
				Entities.splice(i, 1);
			}
		} else if (Entities[i].GarbageMethod == 3) {
			if (Entities[i].getXLoc() > GameCanvas.width)
			{
				Entities.splice(i, 1);
			}
		} else if (Entities[i].GarbageMethod == 4) {
			if (Entities[i].getXLoc() < 0)
			{
				Entities.splice(i, 1);
			}
		} else if (Entities[i].GarbageMethod == 5) {
			if (Entities[i].getXLoc() < 0 || Entities[i].getXLoc() > GameCanvas.width || Entities[i].getYLoc() > GameCanvas.height || Entities[i].getYLoc() < -10)
			{
				Entities.splice(i, 1);
			}
		} else if (Entities[i].GarbageMethod == 6) {
			if (Entities[i].getXLoc() < 0 || Entities[i].getXLoc() > GameCanvas.width || Entities[i].getYLoc() > GameCanvas.height || Entities[i].getYLoc() < -10 || Entities[i].EntityHealth < 1)
			{
				Entities.splice(i, 1);
			}
		} else if (Entities[i].GarbageMethod == 7) {
			if (Entities[i].getYLoc() < -10 || Entities[i].getYLoc() > GameCanvas.height || Entities[i].EntityHealth < 1)
			{
				Entities.splice(i, 1);
			}
		} else if (Entities[i].GarbageMethod != -1) {
			console.log("**WARNING**: Unknown garbage collection method on entity ID " + Entities[i].EntityTag + " in cell " + i + " of Entities");
		}
	}
}

//Generates music based on the red pixels on screen. Currently not used due to taking up over 20% extra CPU usage.
function doMusicGen()
{
	//Used for local testing.
	GameCanvasCxt.crossOrigin = "Annonymous";
	var rawPixelData = GameCanvasCxt.getImageData(0, 0, GameCanvas.width, GameCanvas.height);
	MusicGenPixels = rawPixelData.data;
	for (var i = 0; i < Math.floor(MusicGenPixels.length / 8); i++)
	{
		AudioGen.frequency.value = MusicGenPixels[i];
	}
}

//Runs at a set interval, started from initGame().
function GameLoop()
{
	if (GameState == 1)
		generateLivePlatform();
	drawScreen();
	for (var i = 0; i < Entities.length; i++)
	{
		if (Entities[i].EntityTag == "Player")
		{
			if (Entities[i].YLoc > 0 && Entities[i].YLoc < GameCanvas.height)
			{
				Entities[i].YLoc += Entities[i].YVel;
				//AudioGen.frequency.value += 1;
			} else {
				Entities[i].YLoc = 1;
				//AudioGen.frequency.value = 1;
			}
			if (Entities[i].XLoc > 0 && Entities[i].XLoc < GameCanvas.width)
			{
				Entities[i].XLoc += Entities[i].XVel;
			} else {
				Entities[i].XLoc = 1;
			}
			Entities[i].doAI();
		} else {
			Entities[i].doAI();
			Entities[i].XLoc += Entities[i].XVel;
			Entities[i].YLoc += Entities[i].YVel;
		}
	}
	doCollisions();
	GarbageCollector();
	//doMusicGen();
}

function generateLevel()
{
	Entities.push(new BlockBar(0, getRand(0, 100), getRand(1, 150), 0));
	Entities.push(new BlockBar(Entities[Entities.length - 1].EntityWidth + _XBARSPACER, Entities[Entities.length - 1].getYLoc(), Entities[Entities.length - 1].EntityWidth + GameCanvas.width, 1));
}

function initClasses()
{
	//It's 11 o'clock...
	//Do I really wanna write the animation function only to have to re-write it tomorrow with the entity class after I change classes to extend eachother?
	//Nope.
	//10/29/2016
	
	//Alright, it's a new day, let's do this!
	//10/30/2016
	
	//Init BlockBar
	BlockBar.prototype.getSprite = function(){
		return this.SprLoc;
	}
	BlockBar.prototype.getXLoc = function(){
		return this.XLoc;
	}
	BlockBar.prototype.getYLoc = function(){
		return this.YLoc;
	}
	BlockBar.prototype.doAI = function(){
		//No AI.
	}
}

function spawnEnemy()
{
	if (GameState == 1)
	{
		var EnemyToSpawn = getRand(0, 2);
		if (EnemyToSpawn == 0)
		{
			Entities.push(new EnemyPortal(Math.floor(Math.random() * GameCanvas.width), Math.floor(Math.random() * GameCanvas.height), "EnemyGrunt"));
		} else {
			Entities.push(new EnemyPortal(Math.floor(Math.random() * GameCanvas.width), Math.floor(Math.random() * GameCanvas.height), "EnemyBrute"));
		}
	}
}

//To test something. Prints 'Test complete.' to console.
function TESTFUNC()
{
	console.log("Test complete.");
}

function countCutsceneFrames()
{
	if (GameMode == 1)
	{
		CutsceneFrames += 1;
	}
}

//Created to prevent the readControlsUp functions from becoming cluttered. If no key pressed has a previous case, this will be executed.
function doMenuInput(KeyPressed)
{
	var KeyString = "";
	switch (KeyPressed)
	{
		case 49:
			KeyString = "1";
			break;
		case 50:
			KeyString = "2";
			break;
		case 51:
			KeyString = "3";
			break;
		case 52:
			KeyString = "4";
			break;
		case 53:
			KeyString = "5";
			break;
		case 54:
			KeyString = "6";
			break;
		case 55:
			KeyString = "7";
			break;
		case 56:
			KeyString = "8";
			break;
		case 57:
			KeyString = "9";
			break;
		case 58:
			KeyString = "0";
			break;
	}
	if (MenuID != "NONE")
	{
		if (MenuID == "STARTMENU")
		{
			if (KeyString == "1")
			{
				var speechMaker = window.speechSynthesis;
				var speechText = new SpeechSynthesisUtterance("Login accepted.");
				var voices = window.speechSynthesis.getVoices();
				speechText.rate = 0.3;
				speechText.pitch = 2;
				speechText.voice = voices[4];
				speechMaker.speak(speechText);
				GameState = 4;
				MenuID = "GAMEMODE_SELECT";
			} else if (KeyString == "2") {
				MenuID = "ABOUT";
				GameState = 4;
			} else if (KeyString == "3") {
				MenuID = "OPTIONS";
				GameState = 4;
			}
		} else if (MenuID == "GAMEMODE_SELECT") {
			if (KeyString == "1")
			{
				MenuID = "CORE_SELECT";
			} else if (KeyString == "2") {
				MenuID = "NONE";
				GameState = 1;
				GameMode = 2;
			}
		} else if (MenuID == "CORE_SELECT") {
			//Each number corresponds to the appropriate core number. ex. Core01 is 1, Core02 is 2, etc.
			switch(KeyString)
			{
				case "1":
					console.log("LOADING:CORE01");
					break;
				case "2":
					console.log("LOADING:CORE02");
					GameMode = 1;
					MenuID = "NONE";
					SubGameMode = 2;
					CutsceneTimer = setInterval(countCutsceneFrames, 1000);
					break;
				case "3":
					console.log("LOADING:CORE03");
					break;
				case "4":
					console.log("LOADING:CORE04");
					break;
				case "5":
					console.log("LOADING:CORE05");
					break;
				case "6":
					console.log("LOADING:CORE06");
					break;
				case "7":
					console.log("LOADING:CORE07");
					break;
				case "8":
					console.log("LOADING:CORE08");
					console.log("(؛ ˙ʇɐdʇɐɯ 'buıʇıɐʍ ǝq ןן,ı")
					break;
			}
		} else if (MenuID == "ABOUT") {
			//Since it only has one option, if is just the cleaner way to do it I think.
			if (KeyString == "1")
			{
				GameState = 0;
				MenuID = "STARTMENU";
			}
		} else if (MenuID == "OPTIONS") {
			//All of these are toggle switches unless mentioned otherwise.
			switch (KeyString)
			{
				//In-game music.
				case "1":
					if (PlayMusic < 4)
						PlayMusic += 1;
					else
						PlayMusic = 0;
					break;
				//In-game sound effects.
				case "2":
					if (PlaySFX < 4)
						PlaySFX += 1;
					else
						PlaySFX = 0;
					break;
				//Disable or enable shaders. This does not include the static. If you want to disable the box-shadow, fine, but you're keeping that static, like it or not.
				case "3":
					
					break;
				case "8":
					GameState = 0;
					MenuID = "STARTMENU";
					break;
			}
		}
	}
}

//e is an event arg for keys. This only monitors keys being pressed up.
function readControlsUp(e)
{
	var key = e.keyCode;
	switch(key)
	{
		//W
		case 87:
			if (Entities[findPlayer()].jumpFrame == 0)
			{
				Entities[findPlayer()].jumpFrame = 1;
				Entities[findPlayer()].YVel = -(GravityForce / 1.5);
				Entities[findPlayer()].jumpTimer = setInterval(Entities[findPlayer()].updateJumpFrame, 350); //Nerfed from 500 on 10/24/2016.
			}
			break;
		//A
		case 65:
			Entities[findPlayer()].XVel = 0;
			Entities[findPlayer()].updatePlayerASet("Left");
			break;
		//S
		case 83:
			
			break;
		//D
		case 68:
			Entities[findPlayer()].XVel = 0;
			Entities[findPlayer()].updatePlayerASet("Right");
			break;
		//Space
		case 32:
			Entities[findPlayer()].isShooting = 0;
			Entities[findPlayer()].firePlayerWeapon();
			break;
		//Shift
		case 16:
			break;
		//Everything below this is for menus. Due to some laptops and keyboards not having the number pad, the normal 1-10 keys at the top will be used.
		default:
			doMenuInput(key);
			break;
	}
}

function updateMouseCords(event)
{
	_MOUSEX = event.clientX;
	_MOUSEY = event.clientY;
}

function initGame()
{
	console.log("-=Loading Copland OS Enterprise=-");
	//Init classes.
	console.log("Initializing classes...");
	initClasses();
	
	Entities.push(new Player());
	
	console.log("Starting game loop...");
	setInterval(GameLoop, 10);
	
	//Get canvas element.
	console.log("Retrieving canvas element...");
	GameCanvas = document.getElementById("GameCanvas");
	GameCanvasCxt = GameCanvas.getContext('2d');
	
	//Add keyboard event listeners.
	console.log("Adding keyboard event listeners...");
	document.addEventListener("keydown", readControlsDown, false);
	document.addEventListener("keyup", readControlsUp, false);
	
	GameCanvasCxt.fillStyle = "#FF0000";
	GameCanvasCxt.fillRect(0, 0, GameCanvas.width, GameCanvas.height);
	
	GameCanvasCxt.fillStyle = "#0000FF";
	GameCanvasCxt.font = "30px Arial";
	GameCanvasCxt.fillText("HELLO, NAVI.", 10, 50);
	
	GameCanvasCxt.drawImage(Entities[0].getSprite(), 0, 0);
	console.log("Login accepted. Hello, Lain.");
	generateLevel();
	
	RRSound = new Audio("Audio/RRNoise.ogg");
	
	<!--Thanks to shooting_sparks on StackOverflow for this one!-->
	RRSound.addEventListener("timeupdate", function() {
		var buffer = 1;
		if (this.currentTime > this.duration - buffer)
		{
			this.currentTime = 0;
			this.play();
		}	
	}, false);
	
	RRSound.play();
	
	//AudioGen.type = "square";
	//AudioGen.frequency.value = 440;
	//AudioGen.connect(AudioVol);
	//AudioVol.gain.value = 0.05;
	//AudioVol.connect(AudioCtx.destination);
	//AudioGen.start();
	
	//TODO: Create initSurvival function.
}